// ParseProperties.cpp

#include "StdAfx.h"
